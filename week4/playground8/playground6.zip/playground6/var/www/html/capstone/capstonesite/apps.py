from django.apps import AppConfig


class CapstonesiteConfig(AppConfig):
    name = 'capstonesite'
